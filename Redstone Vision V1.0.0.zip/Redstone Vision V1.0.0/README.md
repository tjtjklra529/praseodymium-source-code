# Redstone Vision 0.2.1 (Minecraft Java 1.21.1)

This ZIP is a standalone resource pack. The optional companion mod is not required and the pack does not reference it.

## Included in the standalone pack

- 128px clean, bordered wool textures in all 16 colors, based on the submitted white-wool style
- white OFF / black ON redstone lamps with a compact centre indicator
- solid clean redstone dust following vanilla corner/junction geometry, with large 0–15 power badges
- visible farmland moisture stages 0–7
- 128px note-block displays for all 23 instruments, 25 pitches and powered states
- exact power badges for daylight detectors, weighted pressure plates and sculk sensors (targets stay vanilla)
- directional/status textures for repeaters, comparators, observers, dispensers, droppers and redstone rails
- OPEN/CLOSED and POWER/MANUAL panels on every 1.21.1 door, trapdoor and fence gate
- RUNNING/LOCKED indicators on hoppers

## Install

1. Put `RedstoneVision-1.21.1-v0.2.1.zip` in `%appdata%\.minecraft\resourcepacks`.
2. Enable it in Options > Resource Packs.
3. Keep it above other packs that replace redstone models.

The optional Fabric companion adds dynamic netherite display faces and exact comparator-output overlays. Removing the mod is safe: worlds contain no custom blocks or saved mod data.
